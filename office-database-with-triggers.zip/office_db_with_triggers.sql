-- Office Database with Triggers

-- employee table --
create table employee (
  emp_id int primary key, 
  first_name varchar(40), 
  last_name varchar(40),
  birth_date date, 
  sex varchar(1), 
  salary int, 
  super_id int,
  branch_id int
);

-- branch table --
create table branch (
  branch_id int primary key,
  branch_name varchar(40),
  mgr_id int,
  mgr_start_date date,
  foreign key(mgr_id) references employee(emp_id) on delete set null
);

alter table employee add foreign key (branch_id) references branch(branch_id) on delete set null;
alter table employee add foreign key (super_id) references employee(emp_id) on delete set null;

-- client table --
create table client (
  client_id int primary key, 
  client_name varchar(40), 
  branch_id int,
  foreign key(branch_id) references branch(branch_id)
);

-- works with table --
create table works_with (
  emp_id int, 
  client_id int, 
  total_sales int,
  primary key (emp_id, client_id), 
  foreign key(emp_id) references employee(emp_id) on delete cascade, 
  foreign key(client_id) references client(client_id) on delete cascade
);

-- branch supplier table --
create table branch_supplier (
  branch_id int, 
  supplier_name varchar(60), 
  supply_type varchar(60),
  primary key (branch_id, supplier_name),
  foreign key (branch_id) references branch(branch_id) on delete cascade
);

-- audit tables for triggers --
create table data_stamp (
  message varchar(255)
);

create table sex_stamp (
  message varchar(255)
);

-- trigger: log new employees --
delimiter $$
create trigger data_stamp_trigger before insert
on employee
for each row 
begin
  insert into data_stamp values ("Added new employee");
end$$
delimiter ;

-- trigger: log employee gender --
delimiter $$
create trigger sex_stamp_trigger before insert
on employee
for each row 
begin 
  if new.sex = "M" then 
    insert into sex_stamp values ("Added male employee");
  elseif new.sex = "F" then 
    insert into sex_stamp values ("Added female employee");
  else 
    insert into sex_stamp values ("Added employee with unspecified sex");
  end if;
end$$
delimiter ;

