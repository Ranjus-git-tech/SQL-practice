# Office Database with Triggers

This repository contains a MySQL schema for an **Office Database**, including tables, relationships, and triggers.

## Features
- Tables: `employee`, `branch`, `client`, `works_with`, `branch_supplier`
- Relationships with primary keys and foreign keys
- Sample insert data for employees, branches, suppliers, and clients
- Example queries for selection, aggregation, joins, and nested queries
- **Triggers**:
  - `data_stamp_trigger`: Logs whenever a new employee is added
  - `sex_stamp_trigger`: Logs the gender of new employees

## Setup Instructions
1. Clone or download this repository.
2. Import the SQL file into MySQL:
   ```bash
   mysql -u username -p office_db < office_db_with_triggers.sql
   ```
3. Explore the database with queries.

## Example
```sql
insert into employee values (110, "Kevin", "Malone","1978-02-19","M",69000,106,3);
select * from data_stamp;
select * from sex_stamp;
```

This will log the insertion event in both `data_stamp` and `sex_stamp` tables.

---
Happy querying! 🎉
