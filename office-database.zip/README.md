# 🗄️ Office Database Project

A sample **MySQL database project** inspired by *The Office* (U.S. series).  
This schema models employees, branches, suppliers, clients, and sales.

## 📌 Features
- Relational schema with 5 main tables.
- Sample data for Corporate, Scranton, Stamford, and Buffalo branches.
- Foreign keys and cascading deletes.
- Example queries included.

## 🚀 Getting Started
1. Clone this repo or download the ZIP.  
2. Import into MySQL:
   ```bash
   mysql -u root -p < office_db.sql
   ```
3. Run queries to explore.

## 📊 Example Queries
- Top paid employees
- Union of all company names (branches, clients, suppliers)
- Employees with sales > 30,000
- Clients of Michael Scott’s branch

## 🛠️ Requirements
- MySQL 8.0+

## ✍️ Author
Ranju Poddar
